App({globalData:{role:null}});
